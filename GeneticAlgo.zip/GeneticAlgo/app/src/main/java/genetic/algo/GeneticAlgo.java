package genetic.algo;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class GeneticAlgo {

    public class Gene {
        private int x1, x2, x3, x4;
        private int fitness;

        public Gene(int x1, int x2, int x3, int x4) {
            this.x1 = x1;
            this.x2 = x2;
            this.x3 = x3;
            this.x4 = x4;
            this.fitness = Integer.MAX_VALUE;
        }

        int getFitness(){
            return fitness;
        }
    }

    private int a, b, c, d, y;
    private int populationSize = 2048;
    public double mutationRate;
    private double elitRate = 0.10;
    private int maxIterations = 10000;
    private int iterations;

    private List<Gene> population = new ArrayList<>(populationSize);


    public GeneticAlgo(int a, int b, int c, int d, int y) {

        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.y = y;

        Random rand = new Random();
        for (Gene p: population){
            p = new Gene(rand.nextInt(y/2), rand.nextInt(y/2), rand.nextInt(y/2),
                    rand.nextInt(y/2));
        }
    }

    public String solution(double mutationRate){
        Random rand = new Random();
        iterations = 0;
        int i1, i2;
        while (iterations < maxIterations) {
            // calculating fitness for each gene
            for (Gene p : population) {
                p.fitness = Math.abs(y - equation(p));
            }

            Collections.sort(population, new Comparator<Gene>() {
                public int compare(Gene o1, Gene o2) {
                    return Integer.compare(o1.fitness, o2.fitness);
                }
            });

            if (population.get(0).fitness == 0) {
                return String.format("Solution of this equation is \n[ %1$d, %2$d, %3$d, %4$d] \nwith mutation probability of" +
                                "\n%5$f", population.get(0).x1,
                        population.get(0).x2, population.get(0).x3, population.get(0).x4, mutationRate);

            } else {
                int elitSize = (int) (population.size() * elitRate);

                for (int j = elitSize; j < population.size(); j++) {
                    i1 = rand.nextInt(population.size());
                    i2 = rand.nextInt(population.size());

                    switch (rand.nextInt(4)) {
                        case 0:
                            population.get(i1).x1 = population.get(i2).x1;
                            population.get(i1).x2 = population.get(i2).x2;
                            population.get(i1).x3 = population.get(i2).x3;
                            population.get(i1).x4 = population.get(i2).x4;
                            break;

                        case 1:
                            if (rand.nextInt(2) == 0) {
                                population.get(i1).x2 = population.get(i2).x2;
                                population.get(i1).x3 = population.get(i2).x3;
                                population.get(i1).x4 = population.get(i2).x4;
                            } else {
                                population.get(i1).x1 = population.get(i2).x1;
                            }
                            break;

                        case 2:
                            if (rand.nextInt(2) == 0) {
                                population.get(i1).x3 = population.get(i2).x3;
                                population.get(i1).x4 = population.get(i2).x4;
                            } else {
                                population.get(i1).x1 = population.get(i2).x1;
                                population.get(i1).x2 = population.get(i2).x2;
                            }
                            break;

                        case 3:
                            if (rand.nextInt(2) == 2)
                                population.get(i1).x4 = population.get(i2).x4;
                            else {
                                population.get(i1).x1 = population.get(i2).x1;
                                population.get(i1).x2 = population.get(i2).x2;
                                population.get(i1).x3 = population.get(i2).x3;
                            }
                            break;
                    }

                    if (rand.nextInt(100) * mutationRate < 100 * mutationRate) {
                        switch (rand.nextInt(4)) {
                            case 0:
                                population.get(i1).x1 = rand.nextInt(y / 2);
                                break;
                            case 1:
                                population.get(i1).x2 = rand.nextInt(y / 2);
                                break;
                            case 2:
                                population.get(i1).x3 = rand.nextInt(y / 2);
                                break;
                            case 3:
                                population.get(i1).x4 = rand.nextInt(y / 2);
                        }
                    }
                }

            }
            iterations++;
        }

        return "Out of iteration maximum";

    }

    public String finalSolution(){
        mutationRate = 0.0;
        int tacts = 100;
        // creating array for all possible mutation rates (probabilities)
        double[] mutations = new double[tacts];
        // array for number of iterations for each mutation rate
        long[] numberIterations = new long[tacts];
        for (int i = 0; i < tacts; i++) {
            mutations[i] = mutationRate;
            solution(mutationRate);
            mutationRate += 0.01;
            numberIterations[i] = iterations;
        }
        // choosing optimal mutation rate where minimum of iterations is
        int indexOptimal = Arrays.asList(numberIterations).indexOf(getMinValue(numberIterations));
        mutationRate = mutations[indexOptimal];
        return solution(mutationRate);

    }

    private int equation(Gene gene){
        return a * gene.x1 + b * gene.x2 + c * gene.x3 + d * gene.x4;
    }

    private static long getMinValue(long[] arr){
        long minValue = arr[0];
        for(int i=1; i < arr.length; i++){
            if(arr[i] < minValue){
                minValue = arr[i];
            }
        }
        return minValue;
    }

}
